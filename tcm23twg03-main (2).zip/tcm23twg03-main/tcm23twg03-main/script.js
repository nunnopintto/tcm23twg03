function clearForm() {
    document.getElementById("contact-form").reset();
}